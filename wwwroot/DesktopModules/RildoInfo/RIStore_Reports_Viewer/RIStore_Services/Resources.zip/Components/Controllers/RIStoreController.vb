﻿
Imports System.Linq
Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports System.Web.Routing
Imports DotNetNuke.Web.Api
Imports DotNetNuke.Services.FileSystem
Imports DotNetNuke.Instrumentation

Namespace RI.Modules.RIStore_Services

    Public Class RIStoreController
        Inherits DnnApiController

        Private Shared ReadOnly Logger As ILog = LoggerSource.Instance.GetLogger(GetType(RIStoreController))

        '<ValidateAntiForgeryToken()> _

        ''' <summary>
        ''' Adds folders by portal id
        ''' </summary>
        ''' <param name="portalId"></param>
        ''' <param name="folder">Folder Name</param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        <HttpGet> _
        <RequireHost> _
        Function AddPortalFolders(ByVal portalId As Integer, ByVal folder As String) As HttpResponseMessage
            Try

                FolderManager.Instance.AddFolder(portalId, folder)

                FolderManager.Instance.Synchronize(portalId, "", True, False)

                Return Request.CreateResponse(HttpStatusCode.OK, "success")
            Catch ex As Exception
                Logger.Error(ex)
                Return Request.CreateResponse(HttpStatusCode.OK, New With {.Result = "Ocorrreu um erro. Caso este erro persista, contate o administrador do sistema.", .Msg = ex.Message})
            End Try
        End Function

    End Class
End Namespace