$(function () {

    my.viewModel();

    

});