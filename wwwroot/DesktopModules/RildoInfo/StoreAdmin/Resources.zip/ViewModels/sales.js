﻿
$(function () {

    $('#moduleTitleSkinObject').html(moduleTitle);



});
