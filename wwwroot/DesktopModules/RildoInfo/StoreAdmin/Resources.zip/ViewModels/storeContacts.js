﻿
$(function () {

    my.viewModel();

    $('#moduleTitleSkinObject').html(moduleTitle);

    var buttons = '<ul class="inline">';
    //buttons += '<li><a href="' + addressURL + '" class="btn btn-primary btn-medium" title="Endereço"><i class="fa fa-book fa-lg"></i></a></li>';
    buttons += '<li><a href="' + registrationURL + '" class="btn btn-primary btn-medium" title="Cadastro"><i class="fa fa-edit fa-lg"></i></a></li>';
    buttons += '<li><a href="' + payCondsURL + '" class="btn btn-primary btn-medium" title="Formas e Condições de Pagamento"><i class="fa fa-credit-card fa-lg"></i></a></li>';
    buttons += '<li><a href="' + estimateURL + '" class="btn btn-primary btn-medium" title="Orçamento"><i class="fa fa-briefcase fa-lg"></i></a></li>';
    buttons += '<li><a href="' + smtpURL + '" class="btn btn-primary btn-medium" title="SMTP"><i class="fa fa-envelope-o fa-lg"></i></a></li>';
    buttons += '<li><a href="' + statusesManagerURL + '" class="btn btn-primary btn-medium" title="Status"><i class="fa fa-check-circle fa-lg"></i></a></li>';
    buttons += '<li><a href="' + websiteManagerURL + '" class="btn btn-primary btn-medium" title="Website"><i class="fa fa-bookmark fa-lg"></i></a></li>';
    buttons += '<li><a href="' + templatesManagerURL + '" class="btn btn-primary btn-medium" title="Templates"><i class="fa fa-puzzle-piece fa-lg"></i></a></li>';
    buttons += '</ul>';
    $('#buttons').html(buttons);

    $('#replyEmailTextBox').attr({ 'placeholder': $('#emailTextBox').val() });

    $('.icon-info-sign').popover({
        placement: 'top',
        trigger: 'hover'
    });

    my.vm.loadRegions();
    my.vm.loadCountries();

    $('#postalCodeTextBox').inputmask("99.999-999");

    $('#btnUpdateContacts').click(function (e) {
        if (e.clientX === 0) {
            return false;
        }
        e.preventDefault();

            var $this = $(this);
            $this.button('loading');

            var params = [
                {
                    'id': portalID,
                    'name': 'RIW_StorePostalCode',
                    'value': my.vm.postalCode()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StoreAddress',
                    'value': my.vm.street()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StoreUnit',
                    'value': my.vm.unit()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StoreComplement',
                    'value': my.vm.complement()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StoreDistrict',
                    'value': my.vm.district()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StoreCity',
                    'value': my.vm.city()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StoreRegion',
                    'value': my.vm.selectedRegion()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StoreCountry',
                    'value': my.vm.selectedCountry()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StoreEmail',
                    'value': my.vm.email()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StoreReplyEmail',
                    'value': my.vm.replyEmail()
                },
                {
                    'id': portalID,
                    'name': 'RIW_StorePhones',
                    'value': my.vm.phones()
                }
            ];

            $.ajax({
                type: 'PUT',
                contentType: 'application/json; charset=utf-8',
                url: '/desktopmodules/riw/api/store/updatePortalSetting',
                data: JSON.stringify(params)
            }).done(function (data) {
                if (data.Result.indexOf("success") !== -1) {
                    $.pnotify({
                        title: 'Sucesso!',
                        text: 'Informações atualizadas.',
                        type: 'success',
                        icon: 'fa fa-check fa-lg',
                        addclass: "stack-bottomright",
                        stack: my.stack_bottomright
                    });
                } else {
                    $.pnotify({
                        title: 'Erro!',
                        text: data.Result,
                        type: 'error',
                        icon: 'fa fa-times-circle fa-lg',
                        addclass: "stack-bottomright",
                        stack: my.stack_bottomright
                    });
                }
            }).fail(function (jqXHR, textStatus) {
                console.log(jqXHR.responseText);
            }).always(function () {
                $this.button('reset');
            });
    });

});
