Cufon.replace('#divTotals');

