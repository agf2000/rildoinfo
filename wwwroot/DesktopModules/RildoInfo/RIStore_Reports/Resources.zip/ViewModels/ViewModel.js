﻿
my.viewModel = function () {

    // knockout js view model
    my.vm = function () {
        // this is knockout view model
        var self = this;

		
        
        // make view models available for apps
        return {
            
        };

    }();
};